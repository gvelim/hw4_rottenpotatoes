#movie_spec.rb

require 'spec_helper'

describe MoviesController do
	descrine "#index# do	
		it "does something"
		it "and somthing else"
	end
end

